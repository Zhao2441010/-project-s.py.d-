#include<iostream>
#include"mystl.h"
using namespace std;
class ccourse{
public:
    int id=0;
    cstring name="";
    int score=0;
    cstring teacher="";
    cstring when="";
    int cnum=0;
    struct{
        int id;
        cstring name;
    }val[200];
    ccourse&operator=(const ccourse&b){
        if(this==&b)return *this;
        id=b.id;
        name=b.name;
        score=b.score;
        teacher=b.teacher;
        when=b.when;
        cnum=b.cnum;
        for(int i=0;i<cnum;i++){
            val[i].id=b.val[i].id;
            val[i].name=b.val[i].name;
        }
        return *this;
    }
    ccourse(const ccourse&b){
        id=b.id;
        name=b.name;
        score=b.score;
        teacher=b.teacher;
        when=b.when;
        cnum=b.cnum;
        for(int i=0;i<cnum;i++){
            val[i].id=b.val[i].id;
            val[i].name=b.val[i].name;
        }
    }
    void show(){
        cout<<"this class is "<<name<<endl;
        cout<<"the teacher is "<<teacher<<endl;
        cout<<cnum<<" students choose it"<<endl;
    }
    ccourse(int i=0,cstring na="",int s=0,cstring tea="",cstring ti=""):
    id(i),name(na),score(s),teacher(tea),when(ti) {
    }
    void reset(int i,cstring na,int s,cstring tea,cstring ti){
        this->id=i;this->name=na;this->score=s;
        this->teacher=tea;
        this->when=ti;
    }
    void xuanke(int id,cstring na){
        int p=1;
        for(int i=0;i<cnum;i++){
            if(id==val[i].id){
                p=0;break;
            }
        }
        if(p){
            val[cnum].id=id;
            val[cnum].name=na;
            cnum++;
            cout<<na<<" choose "<<name<<" successfully"<<endl;
        }
    }
    void tuike(int id,cstring&na){
        int p=1;
        for(int i=0;i<cnum;i++){
            if(val[i].id==id)p=0;
            if(!p){
                val[i].id=val[i+1].id;
                val[i].name=val[i+1].name;
                if(i==cnum-2)break;
            }
        }
        if(!p)cout<<na.val<<" remove "<<name<<" successfully"<<endl;
    }

};  