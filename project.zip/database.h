#include<iostream>
#include<bits/stdc++.h>
#include"teacher.h"
#include"mystl.h"
#include"student.h"
#include"cource.h"
using namespace std;
class csystem;
class cdatabase{
public:
    unordered_map<int,int> shx;
    unordered_map<int,int>thx;
    unordered_map<int,int> chx;
    cvec<int>vec[100];
    cstudent stu[200];
    cteacher tea[200];
    ccourse cou[80];
    int snum=0;
    int tnum=0;
    int cnum=0;
    int have=0;
    friend csystem;
    cdatabase(){};
    void in(){
        const string path_que="C:/Users/31599/Desktop/da.txt";
        ifstream file(path_que);
        if(!file){
            cout<<"error in open";
            return ;
        }
        file>>snum>>tnum>>cnum>>have;
        for(int i=0;i<snum;i++){
            int id;
            cstring name;
            int age,got;
            file>>id>>name>>age>>got;
            shx[id]=i;
            stu[i].reset(id,name,age,got);
        }for(int i=0;i<tnum;i++){
            int id;
            cstring name;
            double score;
            int age;
            file>>id>>name>>age>>score;
            thx[id]=i;
            tea[i].reset(id,name,age);
            tea[i].score=score;
        }for(int i=0;i<cnum;i++){
            int id;
            cstring name,teacher,ti;
            int score;
            file>>id>>name>>score>>teacher>>ti;
            chx[id]=i;
            cou[i].reset(id,name,score,teacher,ti);

        }for(int i=0;i<have;i++){
            int sid,cid;
            cstring sna,cna;
            file>>sid>>sna>>cid>>cna;
            stu[shx[sid]].xuanke(cid,cna);
            cou[chx[cid]].xuanke(sid,sna);
        }
        int m,k;
        while(1){
            file>>m;
            if(m==0)break;
            while(1){
                file>>k;
                if(k==0)break;
                vec[m].push_back(k);
            }
        }
        file.close();
    }
    void out(){
        const string path_que="C:/Users/31599/Desktop/da.txt";
        ofstream file(path_que);
        if(!file){
            cout<<"error in save";
            return;
        }
        file<<snum<<" "<<tnum<<" "<<cnum<<" "<<have<<endl;
        for(int i=0;i<snum;i++){
            file<<stu[i].id<<" "<<stu[i].name<<" "<<stu[i].age<<" "<<stu[i].got<<endl;
        }for(int i=0;i<tnum;i++){
            file<<tea[i].id<<" "<<tea[i].name<<" "<<tea[i].age<<" "<<tea[i].score<<endl;
        }for(int i=0;i<cnum;i++){
            file<<cou[i].id<<" "<<cou[i].name<<" "<<cou[i].score<<" "<<cou[i].teacher<<" "<<cou[i].when<<endl;
        }for(int i=0;i<snum;i++){
            if(stu[i].cnum!=0){
                for(int j=0;j<stu[i].cnum;j++){
                    file<<stu[i].id<<" "<<stu[i].name<<" "<<stu[i].val[j].id<<" "<<stu[i].val[j].cname<<endl;
                }
            }
        }
        for(int i=1;i<100;i++){
            if(!vec[i].size)continue;
            file<<i<<" ";
            for(auto t:vec[i])file<<t<<" ";
            file<<0<<endl;
        }
        file<<0<<endl;
        file.close();
    }
    void show(){
        cout<<snum<<" "<<tnum<<" "<<cnum<<" "<<have<<endl;
        for(int i=0;i<snum;i++){
            cout<<stu[i].id<<" "<<stu[i].name<<" "<<stu[i].age<<" "<<stu[i].got<<endl;
        }for(int i=0;i<tnum;i++){
            cout<<tea[i].id<<" "<<tea[i].name<<" "<<tea[i].age<<" "<<tea[i].score<<endl;
        }for(int i=0;i<cnum;i++){
            cout<<cou[i].id<<" "<<cou[i].name<<" "<<cou[i].teacher<<" "<<cou[i].score<<" "<<cou[i].when<<endl;
        }for(int i=0;i<snum;i++){
            if(stu[i].cnum!=0){
                for(int j=0;j<stu[i].cnum;j++){
                    cout<<stu[i].id<<" "<<stu[i].name<<" "<<stu[i].val[j].id<<" "<<stu[i].val[j].cname<<endl;
                }
            }
        }
    }

};
class csystem:public cdatabase{
    public:
        int val=0;
        int ind=0;
        cdatabase d;
        csystem(){
            cout<<"lead"<<endl;
            d.in();
            d.show();
            cout<<endl;
        }
        ~csystem(){
            cout<<endl;
            cout<<"saved"<<endl;
            d.out();
        }
        void set(){
            int t,k;
            cout<<"log(1) or rejister(2)"<<endl;
            cin>>t;
            cout<<"student(1) or teacher(2)"<<endl;
            cin>>k;
            p:
            cout<<"enter id and name"<<endl;
            int id;
            cstring name;
            cin>>id>>name;
            if(t==1){
                if(k==1){
                    if(d.stu[d.shx[id]].name==name){
                        val=1;
                        ind=d.shx[id];
                        cout<<"enter successfully"<<endl;
                    }else{
                        cout<<"enter again"<<endl;
                        goto p;
                    }
                }else{
                    if(d.tea[d.thx[id]].name==name){
                        val=2;
                        ind=d.thx[id];
                        cout<<"enter successfully"<<endl;
                    }else{
                        cout<<"enter again"<<endl;
                        goto p;
                    }
                }
            }else{
                if(k==1){
                    for(int i=0;i<d.snum;i++){
                        if(d.stu[i].id==id){
                            cout<<"have "<<id << " and enter again" << endl;
                            goto p;
                        }
                    }
                    cout<<"enter your age and got"<<endl;
                    int age,got;
                    cin>>age>>got;
                    ind=d.snum++;
                    d.stu[ind].reset(id,name,age,got);
                    d.shx[id]=ind;
                    val=1;
                }else{
                    for(int i=0;i<d.tnum;i++){
                        if(d.tea[i].id==id){
                            cout<<"have "<<id << " and enter again" << endl;
                            goto p;
                        }
                    }
                    cout<<"enter your age"<<endl;
                    int age;
                    cin>>age;
                    ind=d.tnum++;
                    d.tea[ind].reset(id,name,age);
                    d.thx[id]=ind;
                    val=2;
                }
            }
        }
        void menu(){
            cout<<"0 leave"<<endl;
            switch(val){
                case 1:
                cout<<"1 choose course"<<endl;
                cout<<"2 tui course"<<endl;
                cout<<"3 check now"<<endl;
                cout<<"4 sort and rate"<<endl;
                cout<<"5 learn order"<<endl;
                cout<<"6 best way to reach school goal"<<endl;
                break;
                case 2:
                cout<<"1 check a student"<<endl;
                cout<<"2 check course"<<endl;
                cout<<"3 open your class"<<endl;
                cout<<"4 sort and rate"<<endl;
                cout<<"5 set learn order"<<endl;
                cout<<"6 check learn order"<<endl;
                break;
            }
        }
        void showorder(int i){
            if(i==0)return;
            if(!d.vec[i].size)cout<<"learn "<<d.cou[d.chx[i]].name <<" directly";
            else {
                cout<<"to learn "<<d.cou[d.chx[i]].name<<" needs: ";
                for(auto t:d.vec[i]){
                    if(d.vec[t].size)cout<<"*"<<d.cou[d.chx[t]].id;
                    cout<<d.cou[d.chx[t]].name<<" ";
                }
            }
            cout<<endl;
            cout<<"enter course id 0 means end"<<endl;
            int t;
            cin>>t;
            showorder(t);       
        }
        void graph(int i){
            if(i==0)return;
            cdeque<int>q;
            cout<<"learn from big num to small one"<<endl;
            int p=1;
            q.push_back(i);
            while(q.size){
                int size=q.size;
                cout<<p++<<endl;
                while(size--){
                    int now=q.front();
                    q.pop_front();
                    cout<<d.cou[d.chx[now]].name<<" ";
                    for(auto t:d.vec[now]){
                        q.push_back(t);
                    }
                }
                cout<<endl;
            }
            cout<<"enter course id 0 means end"<<endl;
            int t;
            cin>>t;
            graph(t);   
        }
        void use(){
            int t=1;
            if(val==1){
                cout<<"hi student"<<endl;
                while(t){
                    system("pause");
                    menu();
                    cin>>t;
                    switch(t){
                        case 1:
                            {cout<<"enter course id"<<endl;
                            int k;
                            cin>>k;
                            int id=d.chx[k];
                            xuanke(d.cou[id]);
                            d.have++;
                        }
                        break;
                        case 2:{
                            int k,id;
                            cout<<"enter course id"<<endl;
                            cin>>k;
                            id=d.chx[k];
                            tuike(d.cou[id]);
                            d.have--;
                        }
                        break;
                        case 3:{
                            stu(d.stu[ind]);}
                        break;
                        case 4:
                        sort_cou();
                        sort_tea();
                        sort_stu();                        
                        d.show();
                        break;
                        case 5:
                        cout<<"enter mood 0 graph 1 list"<<endl;
                        int k;
                        cin>>k;
                        cout<<"enter course id"<<endl;
                        int t;
                        cin>>t;
                        if(k)showorder(t);
                        else graph(t);
                        break;
                        case 6:
                            shortest();
                        break;
                        default:
                        break;
                    }
                }
            }else{
                cout<<"hi teacher"<<endl;
                while(t){
                    system("pause");
                    menu();
                    cin>>t;
                    switch(t){
                        case 1:
                            cout<<"enter stu id"<<endl;
                            int id;
                            cin>>id;
                            stu(d.stu[d.shx[id]]);
                        break;
                        case 2:
                            cout<<"enter course id"<<endl;
                            cin>>id;
                            cou(d.cou[d.chx[id]]);
                        break;
                        case 3:
                            kaike();
                            break;
                        case 4:
                            sort_cou();
                            sort_tea();
                            sort_stu();
                            d.show();
                        break;
                        case 5:
                        cout<<"enter target id"<<endl;
                        cin>>id;
                        setorder(id);
                        break;
                        case 6:
                        cout<<"enter mood 0 graph 1 list"<<endl;
                        int k;
                        cin>>k;
                        cout<<"enter course id"<<endl;
                        int t;
                        cin>>t;
                        if(k)showorder(t);
                        else graph(t);
                        break;
                        default:
                        break;
                    }
                }
            }
        }
        void setorder(int id){
            cout<<"set pre for "<<d.cou[d.chx[id]].name<<endl;
            d.vec[id].clear();
            while(1){
                cout<<"enter preclass id 0 means finish"<<endl;
                int t;
                cin>>t;
                if(t==0)break;
                d.vec[id].push_back(t);
                cout<<"set "<<d.cou[d.chx[t]].name<<" successfully"<<endl;
            }
        }
        void xuanke(ccourse&b){
            if(val!=1){
                return;
            }
            d.stu[ind].xuanke(b.id,b.name);
            b.xuanke(d.stu[ind].id,d.stu[ind].name);
        }
        void shortest(int num=26){
            sort_cou();
            int sum=0;
            cout<<"to reach the score "<<num<<" best way is ";
            for(int i=0;i<d.cnum;i++){
                sum=sum+d.cou[i].score;
                cout<<d.cou[i].name<<" ";
                if(sum>num)break;
            }
            cout<<endl;

        }
        void tuike(ccourse&b){
            if(val!=1){
                return;
            }
            d.stu[ind].tuike(b.id,b.name);
            b.tuike(d.stu[ind].id,d.stu[ind].name);
        }
        void stu(cstudent&a){
            cout<<a.name<<" have choose "<<a.cnum<<" cources"<<endl;
            for(int i=0;i<a.cnum;i++){
                cout<<i+1<<" is "<<a.val[i].cname<<endl;
            }
        }
        void cou(ccourse&a){
            if(val!=2){

                return ;
            }
            cout<<a.name<<" have "<<a.cnum<<" students"<<endl;
            for(int i=0;i<a.cnum;i++){
                cout<<i+1<<" is "<<a.val[i].name<<endl;
            }
        }
        void sort_stu(){
            for(int i=0;i<d.snum;i++){
                for(int j=i+1;j<d.snum;j++){
                    if(d.stu[i].got<d.stu[j].got){
                        cstudent c;
                        c=d.stu[i];
                        d.stu[i]=d.stu[j];
                        d.stu[j]=c;
                    }
                }
            }
            for(int i=0;i<d.snum;i++){
                d.shx[d.stu[i].id]=i;
            }
        }void sort_tea(){
            for(int i=0;i<d.tnum;i++){
                for(int j=i+1;j<d.tnum;j++){
                    if(d.tea[i].score<d.tea[j].score){
                        cteacher c=d.tea[i];
                        d.tea[i]=d.tea[j];
                        d.tea[j]=c;
                    }
                }
            }
            for(int i=0;i<d.snum;i++){
                d.thx[d.tea[i].id]=i;
            }
        }void sort_cou(){
            for(int i=0;i<d.cnum;i++){
                for(int j=i+1;j<d.cnum;j++){
                    if(d.cou[i].score<d.cou[j].score){
                        ccourse c=d.cou[i];
                        d.cou[i]=d.cou[j];
                        d.cou[j]=c;
                    }
                }
            }
            for(int i=0;i<d.snum;i++){
                d.chx[d.cou[i].id]=i;
            }
        }
        void kaike(){
            if(val!=2){
                return;
            }
            cout<<"enter course details id name when score"<<endl;
            int id,score;
            cstring name,tim;
            cin>>id>>name>>tim>>score;
            int cid=d.cnum++;
            d.chx[id]=cid;
            d.cou[cid].id=id;
            d.cou[cid].name=name;
            d.cou[cid].score=score;
            d.cou[cid].when=tim;
            d.cou[cid].teacher=d.tea[ind].name;
            cout<<"open "<<name<<" successfully"<<endl;
        }
};