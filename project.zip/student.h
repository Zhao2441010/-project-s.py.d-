#include<iostream>
#include"mystl.h"
using namespace std;
class cstudent{
public:
    int id=0;
    cstring name="";
    int age=0;
    int got=0;
    int cnum=0;
    struct{
        int id;
        cstring cname;
    }val[20];
    cstudent&operator=(const cstudent&b){
        if(this==&b)return *this;
        id=b.id;
        name=b.name;
        age=b.age;
        got=b.got;
        cnum=b.cnum;
        for(int i=0;i<cnum;i++){
            val[i].cname=b.val[i].cname;
            val[i].id=b.val[i].id;
        }
        return *this;
    }
    cstudent(){}
    cstudent(const cstudent&b){
        id=b.id;
        name=b.name;
        age=b.age;
        got=b.got;
        cnum=b.cnum;
        for(int i=0;i<cnum;i++){
            val[i].cname=b.val[i].cname;
            val[i].id=b.val[i].id;
        }
    }
    cstudent(int i,cstring na,int ag,int go):
    id(i),name(na),age(ag),got(go){}
    void xuanke(int id,cstring na){
        for(int i=0;i<cnum;i++){
            if(id==val[i].id){
                cout<<"you have it"<<endl;
                return ;
            }
        }
        val[cnum].id=id;
        val[cnum].cname=na;
        cnum++;
    }
    void reset(int i,cstring na,int ag,int go){
        id=i,name=na,age=ag;
        got=go;
    }
    void tuike(int id,const cstring &na){
        int p=1;
        for(int i=0;i<cnum;i++){
            if(val[i].id==id){
                p=0;
            }
            if(!p){
                val[i].id=val[i+1].id;
                val[i].cname=val[i+1].cname;
                if(i==cnum-2)break;
            }
        }
        if(p)cout<<"no find "<<na.val<<endl;
        else cnum--;
    }
    void meigua(int num){
        got=got+num;
    }
    void show(){
        cout<<"name: "<<name<<" have "<<cnum<<" cources"<<endl;
        for(int i=0;i<cnum;i++){
            cout<<i+1<<" cource is "<<val[i].cname<<endl;
        }
    }
};