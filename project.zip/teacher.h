#include<iostream>
#include"mystl.h"
using namespace std;
class cteacher{
public:
    int id=0;
    cstring name="";
    double score=0;
    int stot=0;
    int snum=0;
    int age=0;
    /*int cnum=0;
    struct cource{
        int id;
        cstring cname;
    }val[20];*/
    cteacher&operator=(const cteacher&b){
        if(this==&b)return *this;
        id=b.id;
        name=b.name;
        score=b.score;
        stot=b.stot;
        snum=b.snum;
        age=b.age;
        return *this;
    }
    cteacher(const cteacher&b){
        id=b.id;
        name=b.name;
        score=b.score;
        stot=b.stot;
        snum=b.snum;
        age=b.age;
    }
    cteacher(){}
    cteacher(int i,cstring n,int ag){
        id=i;
        name=n;
        age=ag;
    }
    void reset(int i,cstring na,int ag){
        id=i,name=na,age=ag;
    }
    ~cteacher(){}
    /*void kaike(int ci,cstring cn){
        for(int i=0;i<cnum;i++){
            if(ci==val[i].id){
                cout<<"have"<<endl;
                return;
            }
        }
        val[cnum].id=ci;
        val[cnum].cname=cn;
        cnum++;
        if(cnum>19)cout<<"so busy"<<endl;
    }
    void shanke(int ci,cstring cn){
        int p=1;
        for(int i=0;i<cnum;i++){
            if(ci==val[i].id){
                p=0;
            }
            if(!p){
                val[i].id=val[i+1].id;
                val[i].cname=val[i+1].cname;
                if(i==cnum-2)break;
            }
        }
        if(p)cout<<"no class"<<endl;
        else cnum--;
    }
    void show(){
        cout<<"my name: "<<name<<" I have "<<cnum<<"cources"<<endl;
        cout<<"my student give the score "<<score<<endl;
        for(int i=0;i<cnum;i++){
            cout<<"my "<<i+1<<" cource is "<<val[i].cname<<endl;
        }
    }*/
    void pingjiao(int i){
        snum++;
        stot+=i;
        score=stot/snum;
    }
};
