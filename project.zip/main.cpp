#include<iostream>
#include<bits/stdc++.h>
#include"mystl.h"
/*#include"system.h"
#include"teacher.h"
#include"student.h"
#include"cource.h"*/
#include"database.h"
using namespace std;
signed main(){
ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
/*
最短路问题分为
floyd(N^3)算法
核心代码:
初始化ans[i][j]=1e9(足够大)
    for(int k=1;k<=n;k++){
    //k是中转站
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n;j++){
                if(a[i][k]==1e9||a[k][j]==1e9)continue;
                else a[i][j]=min(a[i][j],a[i][k]+a[k][j]);
            }
        }
    }
和单源最短路径djstra(NlogN +K)
维护优先队列,距离当前最近的去操作
    ans[start]=0;
    while(m--){
        cin>>s>>e>>l;
        vec[s].push_back({l,e});
    }
//vec[i]first是距离,second是地点
priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>>pq;
    pq.push({ans[start],start});
    while(pq.size()){
        auto now=pq.top();
        pq.pop();
        if(now.first>ans[now.second])continue;
    //起点到该点距离大于已求出距离,不需要再进队
        for(auto [d,t]:vec[now.second]){
            int w=d+now.first;
            if(w<ans[t]){
            //只有小于的情况才需要更新进队
            //否则不需要
                ans[t]=w;
                pq.push({w,t});
            }
        }
    }
    for(int i=1;i<=n;i++){
        cout<<ans[i]<<" ";
    }
}

*/    
    csystem c;
    c.set();
    c.use();
}