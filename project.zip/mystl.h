#ifndef MYSTL_H
#define MYSTL_H

#include <iostream>
#include <vector>
#include <list>
#include <functional>
#include <stdexcept>
#include <utility>
#include <cstring>
#include <algorithm>
#include <cmath>

using namespace std;
template<class T1,class T2>
struct cpair{
    T1 first;
    T2 second;
    cpair(T1 a,T2 b){
        first=a;
        second=b;
    }
    cpair&operator =(const cpair&b){
        first=b.first;
        second=b.second;
    }
};

// 哈希表类
template <typename Key, typename Value, typename Hash = hash<Key>>
class chx {
private:
    struct Node {
        Key key;
        Value value;
        Node(const Key& k, const Value& v) : key(k), value(v) {}
    };

    vector<list<Node>> table; // 哈希表
    size_t capacity; // 哈希表的容量
    size_t size_;    // 当前存储的元素数量
    Hash hash_function; // 哈希函数

    // 计算哈希值
    size_t hash(const Key& key) const {
        return hash_function(key) % capacity;
    }

    // 重新哈希，扩展哈希表
    void rehash() {
        size_t new_capacity = capacity * 2;
        vector<list<Node>> new_table(new_capacity);

        for (auto& bucket : table) {
            for (auto& node : bucket) {
                size_t new_index = hash_function(node.key) % new_capacity;
                new_table[new_index].push_back(node);
            }
        }

        table = move(new_table);
        capacity = new_capacity;
    }

public:
    // 构造函数
    chx(size_t initial_capacity = 16) : capacity(initial_capacity), size_(0), table(initial_capacity) {}

    // 插入键值对
    void insert(const Key& key, const Value& value) {
        size_t index = hash(key);
        auto& bucket = table[index];

        // 检查是否已存在相同的键
        for (auto& node : bucket) {
            if (node.key == key) {
                node.value = value; // 更新值
                return;
            }
        }

        bucket.emplace_back(key, value);
        ++size_;

        // 负载因子大于0.75时，重新哈希
        if (size_ > capacity * 0.75) {
            rehash();
        }
    }

    // 查找键对应的值
    Value& at(const Key& key) {
        size_t index = hash(key);
        auto& bucket = table[index];

        for (auto& node : bucket) {
            if (node.key == key) {
                return node.value;
            }
        }

        throw out_of_range("Key not found");
    }

    // 删除键值对
    void erase(const Key& key) {
        size_t index = hash(key);
        auto& bucket = table[index];

        for (auto it = bucket.begin(); it != bucket.end(); ++it) {
            if (it->key == key) {
                bucket.erase(it);
                --size_;
                return;
            }
        }

        throw out_of_range("Key not found");
    }

    // 判断是否包含某个键
    bool contains(const Key& key) const {
        size_t index = hash(key);
        const auto& bucket = table[index];

        for (const auto& node : bucket) {
            if (node.key == key) {
                return true;
            }
        }

        return false;
    }

    // 获取当前大小
    size_t size() const {
        return size_;
    }

    // 清空哈希表
    void clear() {
        table.clear();
        table.resize(capacity);
        size_ = 0;
    }

    // 遍历哈希表
    void traverse() const {
        for (const auto& bucket : table) {
            for (const auto& node : bucket) {
                cout << "Key: " << node.key << ", Value: " << node.value << endl;
            }
        }
    }

    // 重载 [] 运算符
    Value& operator[](const Key& key) {
        size_t index = hash(key);
        auto& bucket = table[index];

        for (auto& node : bucket) {
            if (node.key == key) {
                return node.value; // 如果键存在，直接返回对应的值
            }
        }

        // 如果键不存在，插入一个默认构造的值，并返回引用
        bucket.emplace_back(key, Value());
        ++size_;

        // 负载因子大于0.75时，重新哈希
        if (size_ > capacity * 0.75) {
            rehash();
        }

        return bucket.back().value;
    }
};

// 双端队列类
template <class T>
class cdeque {
public:
    T* val;
    int size = 0;
    int mxsize = 20;
    int head = 0, tail = 0;

    cdeque() {
        val = new T[mxsize];
    }

    ~cdeque() {
        delete[] val;
    }

    // 在队列头部插入元素
    void push_front(T va) {
        if (size == mxsize) {
            resize();
        }
        head = (head - 1 + mxsize) % mxsize; // 头指针向前移动
        val[head] = va;
        size++;
    }

    // 在队列尾部插入元素
    void push_back(T va) {
        if (size == mxsize) {
            resize();
        }
        val[tail] = va;
        tail = (tail + 1) % mxsize; // 尾指针向后移动
        size++;
    }

    // 从队列头部删除元素
    void pop_front() {
        if (size == 0) return;
        head = (head + 1) % mxsize; // 头指针向后移动
        size--;
    }

    // 从队列尾部删除元素
    void pop_back() {
        if (size == 0) return;
        tail = (tail - 1 + mxsize) % mxsize; // 尾指针向前移动
        size--;
    }

    // 获取队列头部元素
    T& front() {
        if (size == 0) throw runtime_error("Queue is empty");
        return val[head];
    }

    // 获取队列尾部元素
    T& back() {
        if (size == 0) throw runtime_error("Queue is empty");
        return val[(tail - 1 + mxsize) % mxsize];
    }

    // 获取队列中第 i 个元素
    T& operator[](int i) {
        if (i < 0 || i >= size) throw out_of_range("Index out of range");
        int index = (head + i) % mxsize;
        return val[index];
    }

    // 扩容函数
    void resize() {
        mxsize *= 2;
        T* nv = new T[mxsize];
        for (int i = 0; i < size; i++) {
            nv[i] = val[(head + i) % (mxsize / 2)]; // 将旧数据复制到新数组
        }
        delete[] val;
        val = nv;
        head = 0; // 重置头尾指针
        tail = size;
    }
};

// 二分查找函数
template<class T>
int find(T val, T*a, int mxsize) {
    int l = 0, r = mxsize - 1;
    while (l <= r) {
        int mid = (l + r) >> 1;
        if (a[mid] > val) r = mid - 1;
        else l = mid + 1;
    }
    if (a[r] == val) return r;
    else return -1;
}

template<class T>
int lower(T val, T*a, int mxsize) {
    if (a[0] > val) return -1e9;
    int l = 0, r = mxsize - 1;
    while (l <= r) {
        int mid = (l + r) >> 1;
        if (a[mid] >= val) r = mid - 1;
        else l = mid + 1;
    }
    return a[r];
}

template<class T>
int upper(T val, T*a, int mxsize) {
    if (val > a[mxsize - 1]) return -1e9;
    int l = 0, r = mxsize - 1;
    while (l <= r) {
        int mid = (l + r) >> 1;
        if (a[mid] > val) r = mid - 1;
        else l = mid + 1;
    }
    return a[l];
}

// 优先队列类
template<class T, class compare = less<T>>
class cpr_queue {
public:
    compare cmp;
    int size = 0, mxsize = 10;
    T* val = new T[10];
    cpr_queue() {}
    ~cpr_queue() {
        delete[] val;
    }
    void push(T va) {
        if (size >= mxsize) {
            T* nv = new T[2 * mxsize];
            for (int i = 0; i < size; i++) {
                nv[i] = val[i];
            }
            delete[] val;
            val = nv;
            mxsize *= 2;
        }
        int l = 0, r = size - 1;
        while (l <= r) {
            int mid = (l + r) >> 1;
            if (cmp(val[mid], va)) l = mid + 1;
            else r = mid - 1;
        }
        int i = l;
        if (i == size) {
            val[size] = va;
            size++;
        } else {
            for (int j = size + 1; j > i; j--) {
                val[j] = val[j - 1];
            }
            val[i] = va;
            size++;
        }
    }
    T& top() {
        if (size) return val[size - 1];
    }
    void pop() {
        if (size) size--;
    }
};

// 快速排序函数
template<class T, class cmp = less<T>>
void kp(T* begin, T* end, cmp func = cmp()) {
    if (begin > end) return;
    T* mid = (begin + end) >> 1;
    T* l = begin;
    T* r = end;
    while (l < r) {
        while (func(*l, *mid)) l++;
        while (func(*mid, *r)) r--;
        if (l < r) {
            T t = *l;
            *l = *r;
            *r = t;
        }
    }
    kp(begin, --r, func);
    kp(++l, end, func);
}

template<class T>
void kp(T* begin, T* end, bool(*func)(T, T)) {
    if (begin > end) return;
    T* mid = (begin + end) >> 1;
    T* l = begin;
    T* r = end;
    while (l < r) {
        while (func(*l, *mid)) l++;
        while (func(*mid, *r)) r--;
        if (l < r) {
            T t = *l;
            *l = *r;
            *r = t;
        }
    }
    kp(begin, --r, func);
    kp(++l, end, func);
}

// 栈类
template<class T>
class cstack {
public:
    int size = 0, mxsize = 9;
    T* val = nullptr;
    cstack() {
        val = new T[10];
    }
    ~cstack() {
        delete[] val;
    }
    void pop() {
        if (size == 0) return;
        size--;
    }
    void push(T b) {
        if (size >= mxsize) {
            T* nv = new T[2 * mxsize];
            for (int i = 1; i <= mxsize; i++) {
                nv[i] = val[i];
            }
            mxsize = 2 * mxsize - 1;
            delete[] val;
            val = nv;
        }
        size++;
        val[size] = b;
    }
    T& top() {
        return val[size];
    }
    void clear() {
        size = 0;
    }
};

// 字符串类
class cstring {
public:
    char* val = nullptr;
    int size = 0;

    cstring(const char* p) {
        if (p == nullptr) {
            val = new char[1];
            val[0] = '\0';
        } else {
            size = strlen(p);
            val = new char[size + 1];
            for (int i = 0; i < size; i++) {
                val[i] = p[i];
            }
            val[size] = '\0';
        }
    }
    cstring() {
        val = new char[1];
        val[0] = '\0';
    }
    cstring(const cstring& b) {
        size = b.size;
        val = new char[size + 1];
        for (int i = 0; i < size; i++) {
            val[i] = b.val[i];
        }
        val[size] = '\0';
    }
    ~cstring() { delete[] val; }

    char& operator[](int i) {
        return val[i];
    }
    cstring operator=(const cstring& b) {
        if (this == &b) return *this;
        delete[] val;
        size = b.size;
        val = new char[size + 1];
        strcpy(val, b.val);
        val[size] = '\0';
        return *this;
    }
    bool operator==(const cstring& b) {
        if (size != b.size) return false;
        for (int i = 0; i < size; i++) {
            if (val[i] != b.val[i]) return false;
        }
        return true;
    }
    bool operator!=(const cstring& b) {
        return !(*this == b);
    }
    bool operator<(const cstring& b) {
        if (*this == b) return false;
        if (size == b.size) {
            for (int i = 0; i < size; i++) {
                if (val[i] != b.val[i]) return val[i] < b.val[i];
            }
        }
        return size < b.size;
    }
    bool operator>(const cstring& b) {
        return (*this != b) && !(*this < b);
    }
    cstring operator+=(const cstring& b) {
        char* nv = new char[size + b.size + 1];
        int i = 0;
        for (; i < size; i++) {
            nv[i] = val[i];
        }
        for (int j = 0; j < b.size; j++) {
            nv[i + j] = b.val[j];
        }
        delete[] val;
        val = nv;
        size = size + b.size;
        val[size] = '\0';
        return *this;
    }
    cstring operator+(const cstring& b) {
        cstring a = *this;
        return a += b;
    }
    int find(const cstring& b) {
        if (size < b.size) {
            return size;
        }
        for (int i = 0; i < size; i++) {
            if (i + b.size > size) break;
            for (int j = 0; j < b.size; j++) {
                if (j == b.size - 1 && val[i + j] == b.val[j]) return i;
                if (val[i + j] != b.val[j]) break;
            }
        }
        return size;
    }
};

istream& operator>>(istream& is, cstring& s) {
    char p[(int)1e4];
    is >> p;
    s = cstring(p);
    return is;
}
ifstream& operator>>(ifstream& is, cstring& s) {
    char p[(int)1e4];
    is >> p;
    s = cstring(p);
    return is;
}
ostream& operator<<(ostream& os, cstring& s) {
    os << s.val;
    return os;
}
ofstream& operator<<(ofstream& os, cstring& s) {
    os << s.val;
    return os;
}

// 向量类
template<class T>
class cvec {
public:
    int size, mxsize;
    T* val = nullptr;

    cvec(int num = 0) : size(num), mxsize(max(10, 2 * num)) {
        val = new T[mxsize];
    }

    cvec(const cvec& b) : size(b.size), mxsize(b.mxsize) {
        val = new T[mxsize];
        for (int i = 0; i < size; i++) {
            val[i] = b[i];
        }
    }
    void erase(int x){
        if(x<0||x>this->size)return;
        for(int i=x;i<size-1;i++){
            val[i]=val[i+1];
        }
        size--;
    }
    cvec& operator=(const cvec& b) {
        if (this == &b) return *this;
        delete[] val;
        size = b.size;
        mxsize = b.mxsize;
        val = new T[mxsize];
        for (int i = 0; i < size; ++i) {
            val[i] = b[i];
        }
        return *this;
    }

    ~cvec() {
        delete[] val;
    }

    void push_back(T va) {
        if (size >= mxsize) {
            T* nv = new T[2 * mxsize];
            for (int i = 0; i < size; i++) {
                nv[i] = val[i];
            }
            delete[] val;
            mxsize = 2 * mxsize;
            val = nv;
        }
        val[size] = va;
        size++;
    }
    void pop_back() {
        if (size > 0) size--;
    }

    T& operator[](int i) {
        return val[i];
    }

    T* begin() {
        return val;
    }

    T* end() {
        return val + size;
    }

    const T* begin() const {
        return val;
    }

    const T* end() const {
        return val + size;
    }

    const T& operator[](int i) const {
        return val[i];
    }

    void clear() {
        size = 0;
    }
};

// 链表类
template<class T>
struct node {
    T val;
    node<T>* pre = nullptr;
    node<T>* next = nullptr;
    node(T va) : val(va) {}
    bool operator()(node<T> b) {
        return val > b.val;
    }
};

template<class T>
class clist {
public:
    node<T>* root = nullptr;
    node<T>* tail = nullptr;
    int size = 0;
    clist() {}
    ~clist() {
        node<T>* now = root;
        while (1) {
            if (now == nullptr) {
                break;
            } else {
                node<T>* t = now;
                now = now->next;
                delete t;
            }
        }
    }
    void push_back(T val) {
        node<T>* t = new node<T>(val);
        if (root == nullptr) {
            root = t;
            tail = t;
        } else {
            t->pre = tail;
            tail->next = t;
            tail = t;
        }
        size++;
    }
    void push_front(T val) {
        node<T>* t = new node<T>(val);
        if (root == nullptr) {
            root = t;
            tail = t;
        } else {
            node<T>* l = root;
            l->pre = t;
            t->next = l;
            root = t;
        }
        size++;
    }
    void pop_back() {
        if (root != nullptr) {
            tail = tail->pre;
            delete tail->next;
            tail->next = nullptr;
            size--;
        }
        if (size == 0) {
            root = tail = nullptr;
        }
    }
    void pop_front() {
        if (root != nullptr) {
            node<T>* t = root;
            root = root->next;
            delete t;
            size--;
        }
        if (size == 0) root = tail = nullptr;
    }
    node<T>* indx(int i) {
        if (0 <= i && i < size) {
            node<T>* t = root;
            while (i--) {
                t = t->next;
            }
            return t;
        }
    }
    T& operator[](int i) {
        if (0 <= i && i < size) {
            return indx(i)->val;
        }
    }
    void insert(int i, T val) {
        if (i == 0) this->push_front(val);
        else if (i == size) this->push_back(val);
        else {
            node<T>* t = new node<T>(val);
            node<T>* q = this->indx(i - 1);
            node<T>* x = q->next;
            t->pre = q;
            t->next = x;
            q->next = t;
            x->pre = t;
            size++;
        }
    }
    void pop(int i) {
        if (i == 0) this->pop_front();
        else if (i == size - 1) this->pop_back();
        else {
            node<T>* wait = this->indx(i);
            wait->pre->next = wait->next;
            wait->next->pre = wait->pre;
            delete wait;
            size--;
        }
    }
    int find(T& val) {
        int ind = 0;
        node<T>* now = root;
        while (1) {
            if (now->val == val) {
                return ind;
            } else {
                now = now->next;
                ind++;
            }
            if (ind == this->size) return ind;
        }
    }
    void show() {
        if (root == nullptr) {
            cout << "empty" << endl;
            return;
        }
        node<T>* now = root;
        while (1) {
            cout << now->val << " ";
            if (now->next == nullptr) break;
            now = now->next;
        }
        cout << endl;
    }
};

// 交换元素函数
template <class T>
void swap_ele(node<T> a, node<T> b) {
    node<T> t = a;
    a.val = b.val;
    b.val = t.val;
}

// 链表元素遍历函数
template<class T>
node<T>* advance(node<T>* a, int num) {
    if (a == nullptr) {
        cout << "empty" << endl;
    } else if (num >= 0) {
        while (num--) {
            if (a->next == nullptr) break;
            a = a->next;
        }
        if (num > 0) {
            cout << "out size" << endl;
        } else {
            return a;
        }
    } else if (num < 0) {
        while (num++) {
            if (a->pre == nullptr) break;
            a = a->pre;
        }
        if (num < 0) {
            cout << "out size" << endl;
        } else {
            return a;
        }
    }
}

#endif // MYSTL_H