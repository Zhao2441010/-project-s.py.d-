import tkinter as tk
import sys
import queue
import sqlite3
from tkinter import messagebox
import openpyxl
from PIL import Image, ImageTk
"""
快捷方式指令
cd D:\my rubbish\1 homework\py_version
python -m venv venv
venv\Scripts\activate
pip install Pillow openpyxl
pip install pyinstaller
pyinstaller --onefile --hidden-import=Pillow --hidden-import=openpyxl "D:\my rubbish\1 homework\py_version\main.py"

"""

excel_in_path="D:/my rubbish/1 homework/垃圾/1下 作业/以练习项目为目的写的项目/mydata.xlsx"
excel_in_path="D:/my rubbish/1 homework/垃圾/1下 作业/以练习项目为目的写的项目/mydata.xlsx"
db_path="D:/my rubbish/1 homework/垃圾/1下 作业/以练习项目为目的写的项目/mydata.db"

# global conn,cur,user,root
# global course_data,linjie_list,db_courseinddict

# 0   1    2        3      4
# id name password age ||score
# 0  1     2     3       4     5     6
# id name teaid teaname score time stu_num

# 数据库函数
def first_time():
    global conn,cur
    cur.execute("""
            CREATE TABLE IF NOT EXISTS student(
                id INTEGER PRIMARY KEY UNIQUE,
                name TEXT  NOT NULL,
                password TEXT NOT NULL,
                age INTEGER NOT NULL,
                score INTEGER NOT NULL
                )
                """)
    cur.execute("""
            CREATE TABLE IF NOT EXISTS teacher(
                id INTEGER PRIMARY KEY UNIQUE,
                name TEXT NOT NULL,
                password TEXT NOT NULL,
                age INTEGER NOT NULL
                )
                """)
    cur.execute("""
            CREATE TABLE IF NOT EXISTS course(
               id INTEGER PRIMARY KEY UNIQUE,
               name TEXT NOT NULL,
               teacher_id INTEGER NOT NULL,
               teacher_name TEXT NOT NULL,
               score INTEGER NOT NULL, 
               time TEXT NOT NULL,
               stu_num INTEGER NOT NULL
               )
                """)
    cur.execute("""
            CREATE TABLE IF NOT EXISTS student_course(
                student_id INTEGER NOT NULL,
                course_id INTEGER NOT NULL,
                PRIMARY KEY (student_id, course_id),
                FOREIGN KEY (student_id) REFERENCES student(id),
                FOREIGN KEY (course_id) REFERENCES course(id)
            )
            """)
    cur.execute("""
            CREATE TABLE IF NOT EXISTS course_course(
                course_id INTEGER NOT NULL,
                pre_course_id INTEGER,
                PRIMARY KEY (course_id, pre_course_id),
                FOREIGN KEY (course_id) REFERENCES course(id),
                FOREIGN KEY (pre_course_id) REFERENCES course(id)
                )
            """)
    cur.execute("""
            INSERT OR IGNORE INTO teacher (id,name,age,password) VALUES (?,?,?,?)
                """,(1,"章英",40,"123456"))
    cur.execute("""
            INSERT OR IGNORE INTO teacher (id,name,age,password) VALUES (?,?,?,?)
                """,(101,"online 翁凯",40,"123456"))
    cur.execute("""
            INSERT OR IGNORE INTO student (id,name,age,score,password) VALUES (?,?,?,?,?)
                """,(1,"张三",18,25,"123456"))
    cur.execute("INSERT OR IGNORE INTO course(id,name,teacher_name,teacher_id,score,time,stu_num) VALUES (?,?,?,?,?,?,?)",(1,"c++","章英",1,5,"8.am",1))
    cur.execute("INSERT OR IGNORE INTO course(id,name,teacher_name,teacher_id,score,time,stu_num) VALUES (?,?,?,?,?,?,?)",(2,"c++exp","章英",1,5,"2.pm",1))
    cur.execute("INSERT OR IGNORE INTO course(id,name,teacher_name,teacher_id,score,time,stu_num) VALUES (?,?,?,?,?,?,?)",(101,"c++","online 翁凯",101,5,"online",0))
    cur.execute("INSERT OR IGNORE INTO course_course(course_id,pre_course_id) VALUES (?,?)",(2,1))
    cur.execute("INSERT OR IGNORE INTO student_course(student_id,course_id) VALUES (?,?)",(1,1))
    cur.execute("INSERT OR IGNORE INTO student_course(student_id,course_id) VALUES (?,?)",(1,2))

    conn.commit()
    
    destroy_sheet(t_path=excel_in_path)
    creat_sheet(t_path=excel_in_path)
    wb=openpyxl.load_workbook(excel_in_path)
    ws_teacher=wb["teacher"]
    ws_student=wb["student"]
    ws_course=wb["course"]
    ws_student_course=wb["student_course"]
    ws_course_course=wb["course_course"]
    
    ws_teacher.append([1,"章英","123456",40])
    ws_teacher.append([101,"online 翁凯","123456",40])
    ws_student.append([1,"张三","123456",18,25])
    ws_course.append([1,"c++","章英",1,5,"8.am",1])
    ws_course.append([2,"c++exp","章英",1,5,"2.pm",1])
    ws_course.append([101,"c++","online 翁凯",101,5,"online",0])
    
    ws_course_course.append([2,1])
    ws_student_course.append([1,1])
    
    wb.save(excel_in_path)
    wb.close()
    
    
    return None

def check_database():
    global conn,cur
    cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    content=cur.fetchall()
    print(content)
    cur.execute("SELECT *FROM student")
    content=cur.fetchall()
    print(content)
    cur.execute("SELECT *FROM teacher")
    content=cur.fetchall()
    print(content)
    cur.execute("SELECT *FROM course")
    content=cur.fetchall()
    print(content)
    cur.execute("SELECT *FROM student_course")
    content=cur.fetchall()
    print(content)
    cur.execute("SELECT *FROM course_course")
    content=cur.fetchall()
    print(content)
    return None
def load_couredata():
    global conn,cur,user,root
    global course_data,linjie_list,db_courseinddict
    
    course_data=[]
    db_courseinddict={}
    linjie_list=[[] for _ in range(1000)]
    cur.execute("SELECT * FROM course")
    # 0  1     2     3       4     5     6
    # id name teaid teaname score time stu_num
    content=cur.fetchall()
    
    # print(content)
    
    course_data=[course(i[0],i[1],i[2],i[3],i[4],i[5],i[6]) for i in content]
    
    for i in range(len(course_data)):
        db_courseinddict[course_data[i].id]=i
        
    cur.execute("SELECT * FROM course_course")
    content=cur.fetchall()
    content=[(i[0],i[1]) for i in content]
    for i in content:
        linjie_list[i[0]].append(i[1])

def creat_sheet(t_path=excel_in_path):
    global conn,cur,user,root
    global course_data,linjie_list,db_courseinddict
    
    wb=openpyxl.load_workbook(t_path)
    
    ws_teacher=wb.create_sheet("teacher")
    ws_student=wb.create_sheet("student")
    ws_course=wb.create_sheet("course")
    ws_student_course=wb.create_sheet("student_course")
    ws_course_course=wb.create_sheet("course_course")
    
    ws_teacher.append(["id","name","password","age"])
    ws_student.append(["id","name","password","age","score"])
    ws_course.append(["id","name","teacher_id","teacher_name","score","time","stu_num"])
    ws_student_course.append(["student_id","course_id"])
    ws_course_course.append(["course_id","pre_course_id"])
    
    wb.save(t_path)
    wb.close()
    return None

def destroy_sheet(t_path=excel_in_path):
    wb=openpyxl.load_workbook(t_path)
    sheet_names=wb.sheetnames
    for sheet_name in sheet_names:
        if sheet_name in ["Sheet2","Sheet3","teacher","student","course","student_course","course_course"]:
            wb.remove(wb[sheet_name])
    wb.save(t_path)
    wb.close()
    return None

# 类与对象设计
class users:
    def __init__(self,id,name,age,ls:list,score):
        self.name=name
        self.age=age
        self.id=id
        self.ls=[]
        self.score=score
        
    def kaike(self,course_id:int,course_name,course_score,course_time):
        global cur,conn
        cur.execute("INSERT INTO course(id,name,teacher_id,teacher_name,score,time,stu_num) VALUES (?,?,?,?,?,?,?)",(course_id,course_name,self.id,self.name,course_score,course_time,0))
        conn.commit()
        course_data.append(course(course_id,course_name,self.id,self.name,course_score,course_time,stu_num=0))
        db_courseinddict[course_id]=len(course_data)-1
        user.ls.append(course_data[-1])
        return None
        
class course:
    def __init__(self,id:int,name,teacher_id,teacher_name,score,time,stu_num):  
        self.id=id
        self.name=name
        self.teacher_id=teacher_id
        self.teacher_name=teacher_name
        self.score=score
        self.time=time
        self.stu_num=stu_num
    def show(self):
        return f"{self.id} , {self.name} , 老师：{self.teacher_name} , {self.stu_num}"



# 窗口
def windows_design():
    global conn,cur,user,root
    global course_data,linjie_list,db_courseinddict
    global u_det_frame,adm_menu,tea_menu,stu_menu,root,u_det_ls,ls_head
    global use_frame,use_label,u_name,use_id,upg_button
    
      
    # 初始窗口
    root.title("学生成绩管理系统")
    root.geometry("1000x600")
    # 左框架 用户信息
    use_frame = tk.Frame(root)
    use_frame.pack(side=tk.LEFT,fill=tk.BOTH)
    use_label = tk.Label(use_frame, text="用户信息",font=("黑体", 20))
    use_label.pack()
    u_name = tk.Label(use_frame, text=f"姓名：{user.name}",font=("黑体", 16))
    u_name.pack()
    use_id = tk.Label(use_frame, text=f"id:{user.id}",font=("黑体", 16))
    use_id.pack()
    upg_button=tk.Button(use_frame,text="更新",command=windows_updata)
    upg_button.pack()
    # 右框架 已有课程信息
    u_det_frame=tk.Frame(root)
    u_det_frame.pack(side=tk.TOP,fill=tk.BOTH)
    ls_head=tk.Label(u_det_frame,text=f"{user.name}已有的内容",font=("黑体", 16))
    ls_head.pack()
    u_det_ls=tk.Listbox(u_det_frame,width=80,height=30)
    u_det_ls.pack()
    
# 菜单
    tot_menu=tk.Menu(root)
    root.config(menu=tot_menu)
    # 分菜单,登录 注册 退出
    log_menu=tk.Menu(tot_menu,tearoff=0)
    tot_menu.add_cascade(label="登录",menu=log_menu)
    log_menu.add_command(label="登录",command=login)
    log_menu.add_command(label="注册",command=register)
    def qzquit():
        root.destroy()
    log_menu.add_command(label="退出",command=qzquit)
    # 分菜单 
    # 管理员
    adm_menu=tk.Menu(tot_menu,tearoff=0)
    tot_menu.add_cascade(label="管理员",menu=adm_menu)
    adm_menu.add_command(label="数据管理",command=adm_able)
    # 学生
    stu_menu=tk.Menu(tot_menu,tearoff=0)
    tot_menu.add_cascade(label="学生",menu=stu_menu)
    stu_menu.add_command(label="课程管理",command=stu_update)
    # 教师
    tea_menu=tk.Menu(tot_menu,tearoff=0)
    tot_menu.add_cascade(label="教师",menu=tea_menu)
    tea_menu.add_command(label="开课",command=tea_kaike)
    tea_menu.add_command(label="查询学生",command=check_student)
    tea_menu.add_command(label="设置先修顺序",command=set_learn_order)
    # 通识
    com_menu=tk.Menu(tot_menu,tearoff=0)
    tot_menu.add_cascade(label="课程信息",menu=com_menu)
    com_menu.add_command(label="课程查询",command=check_single_course)
    com_menu.add_command(label="先修课查询",command=check_learn_order)
    open_menu=tk.Menu(tot_menu,tearoff=0)
    tot_menu.add_cascade(label="信息公开",menu=open_menu)
    open_menu.add_command(label="课程数据",command=check_all_course)
    open_menu.add_command(label="教师信息",command=check_all_teacher)
    # 功能限制
    menu_disable()

    

def windows_updata():
    u_name.config(text=f"姓名：{user.name}")
    ls_head.config(text=f"用户{user.name}已有的内容")
    use_id.config(text=f"id:{user.id}")
    u_det_ls.delete(0,tk.END)
    if user.name=="HZAU":
        for i in range(len(user.ls)):
            u_det_ls.insert(i,user.ls[i])
        return None
    else:
        for i in range(len(user.ls)):
            u_det_ls.insert(i,user.ls[i].show())
    return None


# 菜单授权
def tea_enable():
    menu_disable()
    tea_menu.entryconfig(0,state="normal")
    tea_menu.entryconfig(1,state="normal")
    tea_menu.entryconfig(2,state="normal")  
def adm_enable():
    menu_disable()
    adm_menu.entryconfig(0,state="normal")
    adm_menu.entryconfig(1,state="normal")
def stu_enable():
    menu_disable()
    stu_menu.entryconfig(0,state="normal")
def menu_disable():
    stu_menu.entryconfig(0,state="disabled")
    
    tea_menu.entryconfig(0,state="disabled")
    tea_menu.entryconfig(1,state="disabled")
    tea_menu.entryconfig(2,state="disabled")
    
    adm_menu.entryconfig(0,state="disabled")
    adm_menu.entryconfig(1,state="disabled")

# 登录登出
def login():
    global conn,cur,user,root
    global course_data,linjie_list,db_courseinddict
    t_root=tk.Toplevel()
    t_root.title("登录")
    t_root.geometry("300x400")
    mod_val=tk.IntVar()
    tk.Radiobutton(t_root,text="学生",variable=mod_val,value=1).pack()
    tk.Radiobutton(t_root,text="教师",variable=mod_val,value=2).pack()
    tk.Label(t_root,text="输入用户名,可忽略").pack()
    name=tk.Entry(t_root)
    name.pack()
    tk.Label(t_root,text="请输入id").pack()
    t_id=tk.Entry(t_root)
    t_id.pack()
    tk.Label(t_root,text="请输入密码").pack()
    password=tk.Entry(t_root,show="*")
    password.pack()
    def login_check():
        global conn,cur,user,root
        name_val=name.get()
        password_val=password.get()
        id_val=t_id.get()
        if name_val=="HZAU" and password_val=="1898":
            messagebox.showinfo("成功","登录成功")
            t_root.destroy()
            user.name=name_val
            user.id=0
            adm_enable()
            cur.execute("select name from teacher")
            content=cur.fetchall()
            tea_list=["华农有三宝","早操","晚课","南湖跑","","教师:"]
            for i in range(len(content)):
                content[i]=content[i][0]
                if content[i][0]=="o":
                    continue
                tea_list.append(content[i])
            tea_list.append("特色专业:")
            tea_list.append("农业")
            tea_list.append("码农")
            user.ls=tea_list
            
            windows_updata() 
            return None
        
        if mod_val.get()==1:
            cur.execute("SELECT * FROM student WHERE id=? AND password=?",(id_val,password_val))
        else:
            cur.execute("SELECT * FROM teacher WHERE id=? AND password=?",(id_val,password_val))
        if cur.fetchone() is None:
            messagebox.showerror("错误","用户名或密码错误")
            t_root.destroy()
            return None
        else:
            if mod_val.get()==1:
                cur.execute("SELECT * FROM student WHERE id=? AND password=?",(id_val,password_val))
                user_data=cur.fetchone()
                user.id=user_data[0]
                user.name=user_data[1]
                user.age=user_data[3]
                user.score=user_data[4]
                cur.execute("SELECT course_id FROM student_course WHERE student_id=?",(user.id,))
                t_list=cur.fetchall()
                fina_list=[]
                for i in range(len(t_list)):
                    fina_list.append(course_data[db_courseinddict[t_list[i][0]]])
                user.ls=fina_list
                stu_enable()
                
            else:
                cur.execute("SELECT * FROM teacher WHERE id=? AND password=?",(id_val,password_val))
                user_data=cur.fetchone()
                user.id=user_data[0]
                user.name=user_data[1]
                user.age=user_data[2]
                cur.execute("SELECT * FROM course WHERE teacher_id=?",(user.id,))
                content=cur.fetchall()
                fina_list=[]
                for i in content:
                    fina_list.append(course_data[db_courseinddict[i[0]]])
                user.ls=fina_list
                tea_enable()
                
            t_root.destroy()
            windows_updata()
            return None

    log_button=tk.Button(t_root,text="登录",command=login_check)
    log_button.pack()

def register():
    global conn,cur,user,root
    t_root=tk.Toplevel()
    t_root.title("注册")
    t_root.geometry("300x600")
    mod_val=tk.IntVar()
    tk.Radiobutton(t_root,text="学生",variable=mod_val,value=1).pack()
    tk.Radiobutton(t_root,text="教师",variable=mod_val,value=2).pack()
    tk.Label(t_root,text="请输入用户名").pack()
    name=tk.Entry(t_root)
    name.pack()
    tk.Label(t_root,text="请输入id").pack()
    t_id=tk.IntVar()
    tk.Entry(t_root,textvariable=t_id).pack()
    tk.Label(t_root,text="请输入年龄").pack()
    age=tk.Entry(t_root)
    age.pack()
    tk.Label(t_root,text="请输入密码").pack()
    password=tk.Entry(t_root,show="*")
    password.pack()
    tk.Label(t_root,text="是学生请输入分数").pack()
    score=tk.Entry(t_root)
    score.pack()
    def register_check():
        global conn,cur,user,root
        name_val=name.get()
        age_val=age.get()
        password_val=password.get()
        score_val=score.get()
        id_val=t_id.get()
        if mod_val.get()==1:
            cur.execute("SELECT * FROM student WHERE ID =?",(id_val,))
            if cur.fetchone() is not None:
                messagebox.showerror("错误","id已存在")
                t_root.destroy()
                return None
            else:
                cur.execute("INSERT INTO student (id,name,age,password,score) VALUES (?,?,?,?,?)",(id_val,name_val,age_val,password_val,score_val))
                conn.commit()
                messagebox.showinfo("成功","注册成功")
                t_root.destroy()
                user.name=name_val
                user.id=id_val
                user.ls=[]
                windows_updata()  
                stu_enable()
        else:
            cur.execute("SELECT * FROM teacher WHERE ID = ?",(id_val,))
            if cur.fetchone() is not None:
                messagebox.showerror("错误","用户名或id已存在")
                t_root.destroy()    
                return None
            else:
                cur.execute("INSERT INTO teacher (id,name,age,password) VALUES (?,?,?,?)",(id_val,name_val,age_val,password_val))
                conn.commit()
                messagebox.showinfo("成功","注册成功")
                t_root.destroy()
                user.name=name_val
                user.id=id_val
                user.ls=[]
                windows_updata()
                tea_enable()
    reg_button=tk.Button(t_root,text="注册",command=register_check)
    reg_button.pack()
    t_root.mainloop()

# 通用功能
def check_single_course():
    global conn,cur,user,root
    global course_data,linjie_list,db_courseinddict
    t_root=tk.Toplevel()
    t_root.title("课程信息")
    t_root.geometry("300x400")
    tk.Label(t_root,text="请输入课程名").pack()
    c_name=tk.Entry(t_root)
    c_name.pack()
    tk.Label(t_root,text="请输入id,不确定填0即可").pack()
    c_id=tk.IntVar()
    tk.Entry(t_root,textvariable=c_id).pack()
    def check_sing_course():
        global conn,cur,user,root
        global course_data,linjie_list,db_courseinddict
        name_val=c_name.get()
        id_val=c_id.get()
        answer_root=tk.Toplevel()
        answer_root.title("课程信息")
        answer_root.geometry("800x600")
        
        exact_frame=tk.Frame(answer_root)
        exact_frame.pack(side=tk.TOP,fill=tk.X)
        tk.Label(exact_frame,text="确切课程信息",font=("黑体", 20)).pack()
        exa_lb=tk.Listbox(exact_frame,width=80,height=10)
        exa_lb.pack()
        
        same_frame=tk.Frame(answer_root)
        same_frame.pack(side=tk.TOP,fill=tk.X)
        tk.Label(same_frame,text="相似课程信息",font=("黑体", 20)).pack()
        sam_lb=tk.Listbox(same_frame,width=80,height=10)
        sam_lb.pack()
        
        
        for i in range(len(course_data)):
            if course_data[i].name==name_val:
                sam_lb.insert(i,course_data[i].show())
            if course_data[i].id==id_val:
                exa_lb.insert(i,course_data[i].show())
        
        answer_root.mainloop()
    che_button=tk.Button(t_root,text="查询",command=check_sing_course)
    che_button.pack()
def check_all_course():
    global conn,cur,user,root
    global course_data,linjie_list,db_courseinddict
    t_root=tk.Toplevel()
    t_root.title("课程信息")
    t_root.geometry("600x400")
    t_lb=tk.Listbox(t_root,width=80,height=5)
    t_lb.pack()
    content=[course_data[i].show() for i in range(len(course_data))]
    for i in range(len(content)):
        t_lb.insert(i,content[i])
        
    tk.Label(t_root,text="请输入课程名").pack()
    c_name=tk.Entry(t_root)
    c_name.pack()
    sam_lb=tk.Listbox(t_root,width=80,height=5)
    sam_lb.pack()
    
    def check_name():
        global conn,cur,user,root
        global course_data,linjie_list,db_courseinddict
        name_val=c_name.get()
        sam_lb.delete(0,tk.END)
        for i in range(len(course_data)):
            if course_data[i].name==name_val:
                sam_lb.insert(i,course_data[i].show())
        
    tk.Button(t_root,text="查询",command=check_name).pack()
        
    t_root.mainloop()
    
def check_all_teacher():
    global conn,cur,user,root
    global course_data,linjie_list,db_courseinddict
    t_root=tk.Toplevel()
    t_root.title("教师信息")
    t_root.geometry("600x400")
    t_lb=tk.Listbox(t_root,width=80,height=10)
    t_lb.pack()
    cur.execute("SELECT * FROM teacher")
    content=cur.fetchall()
    for i in range(len(content)):
        if content[i][1][0]=="o":continue
        t_lb.insert(i,f"教工号:{content[i][0]} 姓名:{content[i][1]}")
    t_root.mainloop()

def check_learn_order():
    global conn,cur,user,root
    global course_data,linjie_list,db_courseinddict
    t_root=tk.Toplevel()
    t_root.title("先修图")
    t_root.geometry("600x400")
    tk.Label(t_root,text="请输入id").pack(side=tk.LEFT)
    lb=tk.Listbox(t_root,width=80,height=10)
    lb.pack()
    c_id=tk.IntVar()
    tk.Entry(t_root,textvariable=c_id).pack()
    def check_order():
        global conn,cur,user,root
        global course_data,linjie_list,db_courseinddict
        lb.delete(0,tk.END)
        id_val=c_id.get()
        data=cengxu(id_val)
        for i in range(len(data)):
            lb.insert(i,data[i])
    che_button=tk.Button(t_root,text="查询",command=check_order)
    che_button.pack()
    t_root.mainloop()
def cengxu(id:int):
    global linjie_list,db_courseinddict,course_data
    q=queue.Queue()
    level=1
    q.put(id)
    content=[]
    used_dic={}
    used_dic[id]=1
    while q.qsize()!=0:
        size=q.qsize()
        t_content=[]
        if level==1:
            t_content.append(f"你想学的:")
        else:
            t_content.append(f"第{level}级先修课:")
        for t in range(size):
            now=q.get()
            t_content.append(f"{course_data[db_courseinddict[now]].name}")
            for t in linjie_list[now]:
                if used_dic.get(t,0)==0:
                    q.put(t)
                    used_dic[t]=1
        level+=1
        if level>4:
            break
        content.append(t_content)
    return content

# 教师区
def set_learn_order():
    global conn,cur,user,root
    global course_data,linjie_list,db_courseinddict
    t_root=tk.Toplevel()
    t_root.title("先修设置")
    t_root.geometry("300x400")
    tk.Label(t_root,text="请输入课程id").pack()
    c_id=tk.IntVar()
    tk.Entry(t_root,textvariable=c_id).pack()
    tk.Label(t_root,text="请输入先修课程id").pack()
    pre_id=tk.IntVar()
    tk.Entry(t_root,textvariable=pre_id).pack()
    def set_order():
        global conn,cur,user,root
        global course_data,linjie_list,db_courseinddict
        id_val=c_id.get()
        pre_val=pre_id.get()
        cur.execute("INSERT OR IGNORE INTO course_course(course_id,pre_course_id) VALUES (?,?)",(id_val,pre_val))
        conn.commit()
        linjie_list[id_val].append(pre_val)
        messagebox.showinfo("成功","设置成功")
        t_root.destroy()
        windows_updata()
    che_button=tk.Button(t_root,text="新增",command=set_order)
    che_button.pack()
    def delete_order():
        global conn,cur,user,root
        global course_data,linjie_list,db_courseinddict
        id_val=c_id.get()
        pre_val=pre_id.get()
        cur.execute("DELETE FROM course_course WHERE course_id=? AND pre_course_id=?",(id_val,pre_val))
        for i in range(len(linjie_list[id_val])):
            if linjie_list[id_val][i]==pre_val:
                linjie_list[id_val].pop(i)
        conn.commit()
        messagebox.showinfo("成功","删除成功")
        t_root.destroy()
        windows_updata()
    del_button=tk.Button(t_root,text="删除",command=delete_order)
    del_button.pack()
    t_root.mainloop()

def check_student():
    global conn,cur,user,root
    global course_data,linjie_list,db_courseinddict
    t_root=tk.Toplevel()
    t_root.title("学生信息")
    t_root.geometry("600x400")
    tk.Label(t_root,text="请输入学生姓名").pack()
    s_name=tk.Entry(t_root)
    s_name.pack()
    def button_check_student():
        global conn,cur,user,root
        global course_data,linjie_list,db_courseinddict
        name_val=s_name.get()
        cur.execute("SELECT * FROM student WHERE name=? ",(name_val,))
        content=cur.fetchall()
        if content==[]:
            messagebox.showerror("错误","没有该学生")
            return None
        else:
            answer_root=tk.Toplevel()
            answer_root.title("学生信息")
            answer_root.geometry("800x600")
            tk.Label(answer_root,text="学生信息",font=("黑体", 20)).pack()
            lb=tk.Listbox(answer_root,width=80,height=5)
            lb.pack()
            for i in range(len(content)):
                lb.insert(i,f"学号:{content[i][0]} , 姓名:{content[i][1]} , 已修学分:{content[i][4]}")
            tk.Label(answer_root,text="学生已选课程",font=("黑体", 20)).pack()
            lb2=tk.Listbox(answer_root,width=80,height=10)
            lb2.pack()
            num=0
            for i in range(len(content)):
                cur.execute("SELECT course_id FROM student_course WHERE student_id=?",(content[i][0],))
                stu_have=cur.fetchall()
                lb2.insert(num,f"学号 {content[i][0]} 学生{content[i][1]}已选课程")
                num+=1
                for j in range(len(stu_have)):
                    now_course=course_data[db_courseinddict[stu_have[j][0]]]
                    lb2.insert(num,f"课程名:{now_course.name} , 教师名:{now_course.teacher_name}")
                    num+=1
                    
                    
                
    che_button=tk.Button(t_root,text="查询",command=button_check_student)
    che_button.pack()
    t_root.mainloop()               
 
def tea_kaike():
    global conn,cur,user,root
    global course_data,linjie_list,db_courseinddict
    t_root=tk.Toplevel()
    t_root.title("开课信息")
    t_root.geometry("300x400")
    tk.Label(t_root,text="请输入课程名").pack()
    c_name=tk.Entry(t_root)
    c_name.pack()
    tk.Label(t_root,text="请输入id").pack()
    c_id=tk.IntVar()
    tk.Entry(t_root,textvariable=c_id).pack()
    tk.Label(t_root,text="请输入学分").pack()
    c_score=tk.IntVar()
    tk.Entry(t_root,textvariable=c_score).pack()
    c_score.set(0)
    
    tk.Label(t_root,text="请输入时间").pack()
    c_time=tk.Entry(t_root)
    c_time.pack()
    def kaike_check():
        global conn,cur,user,root
        global course_data,linjie_list,db_courseinddict
        name_val=c_name.get()
        id_val=c_id.get()
        cur.execute("SELECT * FROM course WHERE id=? ",(id_val,))
        content=cur.fetchall()
        if content!=[]:
            messagebox.showerror("错误","课程id已存在")
            return None
        score_val=c_score.get()
        time_val=c_time.get()
        user.kaike(id_val,name_val,score_val,time_val)
        messagebox.showinfo("成功","开课成功")
        t_root.destroy()
        windows_updata()
    che_button=tk.Button(t_root,text="开课",command=kaike_check)
    che_button.pack()   
    
# 学生区
def stu_update():
    global conn,cur,user,root
    global course_data,linjie_list,db_courseinddict
    t_root=tk.Toplevel()
    t_root.geometry("600x400")
    tk.Label(t_root,text="已有课程").pack()
    have_course=tk.Listbox(t_root,width=80,height=5)
    have_course.pack()
    for i in range(len(user.ls)):
        have_course.insert(i,user.ls[i].show())
    all_course=tk.Listbox(t_root,width=80,height=20)
    all_course.pack()
    for i in range(len(course_data)):
        all_course.insert(i,course_data[i].show())
    
    def stu_choose():
        # ind=all_course.curselection()[0]
        # item=all_course.get(ind)
        # print(item)
        # print(item.split(",")[0])#split 分割为list, [0]是第一个也就是db里面的id
        course_id=int(all_course.get(all_course.curselection()[0]).split(",")[0])
        for i in user.ls:
            if i==int(course_id):
                messagebox.showerror("错误","你已经选过这门课了")
                return None
        user.ls.append(course_data[db_courseinddict[course_id]])
        course_data[db_courseinddict[course_id]].stu_num+=1
        cur.execute("UPDATE course SET stu_num=? WHERE id=?",(course_data[db_courseinddict[course_id]].stu_num,course_id))
        cur.execute("INSERT INTO student_course VALUES(?,?)",(user.id,course_id))
        conn.commit()
        have_course.insert(tk.END,user.ls[-1].show())
        windows_updata()
        messagebox.showinfo("成功","选课成功")
        t_root.destroy()

        
    def stu_withdraw():
        course_id=int(have_course.get(have_course.curselection()[0]).split(",")[0])
        course_data[db_courseinddict[course_id]].stu_num-=1
        for i in range(len(user.ls)):
            if user.ls[i].id==course_id:
                user.ls.pop(i)
                break
        cur.execute("DELETE FROM student_course WHERE student_id=? AND course_id=?",(user.id,course_id))
        cur.execute("UPDATE course SET stu_num=? WHERE id=?",(course_data[db_courseinddict[course_id]].stu_num,course_id))
        conn.commit()
        have_course.delete(0,tk.END)
        for i in range(len(user.ls)):
            have_course.insert(i,user.ls[i])
        windows_updata()
        messagebox.showinfo("成功","退课成功")
        t_root.destroy()
        
    
    # 右键菜单
    t_menu=tk.Menu(t_root,tearoff=0)
    t_menu.add_command(label="选课",command=stu_choose)
    t_menu.add_command(label="退课",command=stu_withdraw)
    t_root.bind("<Button-3>", lambda event: t_menu.post(event.x_root, event.y_root))
    t_root.mainloop()
    return None
    
def adm_able():
    global conn,cur,user,root
    global course_data,linjie_list,db_courseinddict
    t_root=tk.Toplevel()
    t_root.title("管理员功能")
    t_root.geometry("600x400")
    tk.Label(t_root,text="请输入目标地址").pack()
    tar_path=tk.StringVar()
    tar_path.set(excel_in_path)
    tk.Entry(t_root,textvariable=tar_path,width=80).pack()
    def adm_update():
        global conn,cur,user,root
        global course_data,linjie_list,db_courseinddict
        messagebox.showinfo("提示","即将导入信息,追加到现有之中")
        wb=openpyxl.load_workbook(tar_path.get())
        ws_teacher=wb['teacher']
        ws_student=wb['student']
        ws_course=wb['course']
        ws_student_course=wb['student_course']
        ws_course_course=wb['course_course']
        
        for i in range(2,ws_teacher.max_row+1):
            # print(ws_teacher.cell(row=i,column=1).value,ws_teacher.cell(row=i,column=2).value,ws_teacher.cell(row=i,column=3).value,ws_teacher.cell(row=i,column=4).value)
            cur.execute("INSERT OR IGNORE INTO teacher (id,name,password,age) VALUES (?,?,?,?)",(ws_teacher.cell(row=i,column=1).value,ws_teacher.cell(row=i,column=2).value,ws_teacher.cell(row=i,column=3).value,ws_teacher.cell(row=i,column=4).value))
        
        for i in range(2,ws_student.max_row+1):
            cur.execute("INSERT OR IGNORE INTO student (id,name,password,age,score) VALUES (?,?,?,?,?)",(ws_student.cell(row=i,column=1).value,ws_student.cell(row=i,column=2).value,ws_student.cell(row=i,column=3).value,ws_student.cell(row=i,column=4).value,ws_student.cell(row=i,column=5).value))

        for i in range(2,ws_course.max_row+1):
            cur.execute("INSERT OR IGNORE INTO course (id,name,teacher_id,teacher_name,score,time,stu_num) VALUES (?,?,?,?,?,?,?)",(ws_course.cell(row=i,column=1).value,ws_course.cell(row=i,column=2).value,ws_course.cell(row=i,column=3).value,ws_course.cell(row=i,column=4).value,ws_course.cell(row=i,column=5).value,ws_course.cell(row=i,column=6).value,ws_course.cell(row=i,column=7).value))
        
        for i in range(2,ws_student_course.max_row+1):
            cur.execute("INSERT OR IGNORE INTO student_course (student_id,course_id) VALUES (?,?)",(ws_student_course.cell(row=i,column=1).value,ws_student_course.cell(row=i,column=2).value))

        for i in range(2,ws_course_course.max_row+1):
            cur.execute("INSERT OR IGNORE INTO course_course (course_id,pre_course_id) VALUES (?,?)",(ws_course_course.cell(row=i,column=1).value,ws_course_course.cell(row=i,column=2).value))
        conn.commit()
        messagebox.showinfo("成功","导入成功,即将重新登录")
        t_root.destroy()
        windows_updata()
        root.destroy()

        return None
    
    def lead_out():
        global conn,cur,user,root
        global course_data,linjie_list,db_courseinddict
        messagebox.showinfo("提示","即将导出信息,会覆盖原有")
        destroy_sheet(t_path=tar_path.get())
        creat_sheet(t_path=tar_path.get())
        
        
        wb=openpyxl.load_workbook(tar_path.get())
        ws_teacher=wb['teacher']
        ws_student=wb['student']
        ws_course=wb['course']
        ws_student_course=wb['student_course']
        ws_course_course=wb['course_course']
        
        cur.execute("SELECT * FROM teacher")
        content=cur.fetchall()   
        for i in range(len(content)):
            ws_teacher.append((int(content[i][0]),content[i][1],content[i][2],int(content[i][3])))
        
        cur.execute("SELECT * FROM student")
        content=cur.fetchall()
        for i in range(len(content)):
            ws_student.append((int(content[i][0]),content[i][1],content[i][2],int(content[i][3]),int(content[i][4])))
        
# 0   1    2        3      4
# id name password age ||score
# 0  1     2     3       4     5     6
# id name teaid teaname score time stu_num
        
        cur.execute("SELECT * FROM course")
        content=cur.fetchall()
        for i in range(len(content)):
            ws_course.append((int(content[i][0]),content[i][1],int(content[i][2]),content[i][3],int(content[i][4]),content[i][5],int(content[i][6])))

        cur.execute("SELECT * FROM student_course")
        content=cur.fetchall()
        for i in range(len(content)):
            ws_student_course.append((int(content[i][0]),int(content[i][1])))

        cur.execute("SELECT * FROM course_course")
        content=cur.fetchall()
        for i in range(len(content)):
            ws_course_course.append((int(content[i][0]),int(content[i][1])))
        
        wb.save(tar_path.get())
        wb.close()
        messagebox.showinfo("成功","导出成功")
        t_root.destroy()
        
        
        return None

    lead_in_button=tk.Button(t_root,text="新增",width=40,command=adm_update)
    lead_in_button.pack()
    lead_out_button=tk.Button(t_root,text="导出",width=40,command=lead_out)
    lead_out_button.pack()
    t_root.mainloop()
    
# 程序开始与结束
def start():
    global conn,cur,user,root
    global course_data,linjie_list,db_courseinddict
    conn=sqlite3.connect('mydata.db')
    cur=conn.cursor()
    user=users("No details","No details","No details",[],"No details")
    root = tk.Tk()
    return None
def end():   
    conn.commit()
    cur.close()
    conn.close()
    root.quit()
    return None

if __name__ == '__main__':
# 初始化
    start()
# 数据库导入
    # first_time()  #防止牛马删库跑路
    # check_database()
    load_couredata()
# GUI
    windows_design()

# 额外操作 比如调试
    
    
    # root.withdraw()  # 隐藏主窗口
    # # 创建一个新窗口
    # t_root = tk.Toplevel(root)
    # t_root.title("她真好看")
    # t_root.geometry("1000x600")

    # try:
    #     image_path = r"D:\lei.jpg"
    #     image = Image.open(image_path)
    #     photo = ImageTk.PhotoImage(image)
    # except Exception as e:
    #     print(f"加载图片时出错: {e}")
    #     t_root.destroy()
    #     exit()

    # # 创建一个Label控件
    # label = tk.Label(t_root, image=photo)
    # label.image = photo  # 避免被垃圾回收
    # label.place(relwidth=1, relheight=1)  # 让Label填满整个t_root
    # messagebox.showinfo("雷电将军","她真好看")
    # # 阻塞主线程，直到t_root窗口被关闭
    # t_root.wait_window()
    
    # t_root = tk.Toplevel(root)
    # t_root.title("她真好看")
    # t_root.geometry("1000x600")


    # try:
    #     image_path = r"D:\quan.jpg"
    #     image = Image.open(image_path)
    #     photo = ImageTk.PhotoImage(image)
    # except Exception as e:
    #     print(f"加载图片时出错: {e}")
    #     t_root.destroy()
    #     exit()

    # # 创建一个Label控件
    # label = tk.Label(t_root, image=photo)
    # label.image = photo  # 避免被垃圾回收
    # label.place(relwidth=1, relheight=1)  # 让Label填满整个t_root
    # messagebox.showinfo("黄泉","她真好看")
    # # 阻塞主线程，直到t_root窗口被关闭
    # t_root.wait_window()

    # # 显示主窗口
    # root.deiconify()  # 显示主窗口
    
    
# 运行
    root.mainloop()
# 终止
    end()